# MarchWangBot Premium Military Luxury Mini App

ဒီ Project က deploy လုပ်နိုင်တဲ့ starter app ဖြစ်ပါတယ်။ Frontend (dark luxury dashboard), FastAPI backend, SQLite database, Telegram Bot webhook, Telegram Mini App `initData` validation ပါဝင်ပါတယ်။

## ပါဝင်တဲ့ လုပ်ဆောင်ချက်များ
- Telegram Mini App ထဲမှာ dashboard ဖွင့်နိုင်ခြင်း
- Backend က Telegram `initData` ကို စစ်ဆေးပြီး user identity အတည်ပြုခြင်း
- Bot ကို ထည့်ထားတဲ့ group များကို webhook မှတ်တမ်းတင်ခြင်း
- Group Admin ဖြစ်ကြောင်း Telegram Bot API ဖြင့် စစ်ဆေးပြီးမှ settings ပြင်ခွင့်ပေးခြင်း
- Welcome message နဲ့ group rules ကို SQLite မှာ သိမ်း/ပြင်နိုင်ခြင်း
- `/start`, `/help`, `/id`, `/rules` command များ
- Bot အသစ်ဝင်လာတဲ့ member အတွက် configured welcome message ပို့ခြင်း

**သတိ:** Anti-spam / ban / mute ခလုတ်တွေကို ဒီ starter version မှာ တကယ် moderation လုပ်အောင် မချိတ်ရသေးပါ။ Dashboard မှာ အဲဒီအင်္ဂါရပ်တွေကို အတုအယောင်အဖြစ် မပြထားပါ။ နောက်ထပ် moderation endpoints ထည့်နိုင်ပါတယ်။

## 1. လိုအပ်တာ
- Python 3.11+
- Telegram Bot Token (BotFather မှာ ရယူရန်)
- HTTPS hosting တစ်ခု (ဥပမာ Render, Railway, VPS)
- Bot ကို စီမံမယ့် Telegram group ထဲ ထည့်ထားရန်
- Welcome ပို့ဖို့ bot ကို group ထဲမှာ message ပို့ခွင့်ပေးထားရန်

## 2. Local စမ်းသပ်ခြင်း
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```
`.env` ကို ပြင်ပြီး `BOT_TOKEN`, `WEBHOOK_SECRET` ထည့်ပါ. `APP_BASE_URL` ကို deploy ပြီးရင် HTTPS URL နဲ့ ပြင်ပါ.

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```
Local browser မှာ `http://127.0.0.1:8000` ဖွင့်ရင် demo preview ကိုမြင်နိုင်ပါတယ်။ Telegram မှာ authentication အောင်မြင်ဖို့ Mini App ကို Telegram အတွင်းမှဖွင့်ပြီး HTTPS URL သုံးရပါမယ်။

## 3. Hosting တင်ခြင်း
Hosting provider တစ်ခုမှာ Python Web Service တည်ဆောက်ပါ။
- Build/install command: `pip install -r requirements.txt`
- Start command: `uvicorn app:app --host 0.0.0.0 --port $PORT`
- Environment variables: `.env.example` ထဲက values အားလုံးထည့်ပါ။
- Persistent disk မရှိတဲ့ hosting သုံးရင် SQLite data ပျောက်နိုင်ပါတယ်။ Production အတွက် persistent disk သို့မဟုတ် managed PostgreSQL သုံးပါ။
- Deploy ပြီးရင် `APP_BASE_URL=https://သင့်-domain` ဖြစ်ရပါမယ်။

## 4. Telegram webhook ချိတ်ခြင်း
Deploy ပြီး HTTPS URL ရလာတဲ့နောက်:
```bash
curl -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setWebhook" \
  -d "url=${APP_BASE_URL}/telegram/webhook" \
  -d "secret_token=${WEBHOOK_SECRET}" \
  -d 'allowed_updates=["message","my_chat_member","chat_member"]'
```
`WEBHOOK_SECRET` ကို A-Z, a-z, 0-9, `_`, `-` စတဲ့ လက်ခံနိုင်တဲ့ စာလုံးများနဲ့ ရှည်လျားတဲ့ random value သုံးပါ။

Webhook status စစ်ရန်:
```bash
curl "https://api.telegram.org/bot${BOT_TOKEN}/getWebhookInfo"
```

## 5. Mini App Menu Button သတ်မှတ်ခြင်း
1. @BotFather ကိုဖွင့်ပါ။
2. `/setmenubutton` ပို့ပါ။
3. MarchWangBot ကိုရွေးပါ။
4. Button text ကို `♛ Control Panel` လို့ထည့်ပါ။
5. HTTPS URL အပြည့်အစုံထည့်ပါ (ဥပမာ `https://your-domain.example`)။
6. Telegram ထဲမှာ bot ကိုပြန်ဖွင့်ပြီး Menu Button ကိုစမ်းပါ။

## 6. Group အသုံးပြုခြင်း
1. Bot ကို group ထဲထည့်ပါ။
2. Bot ကို Admin ပေးပါ (welcome ပို့ခွင့်အပါအဝင် လိုအပ်တဲ့ permission များသာ)။
3. Group ထဲက `my_chat_member` update ကို webhook ကလက်ခံပြီး group ကို database ထဲမှတ်တမ်းတင်ပါမယ်။
4. Mini App ကို Telegram အတွင်းဖွင့်ပါ။ Group Admin အဖြစ် login ဝင်ထားရင် settings ပြင်နိုင်ပါမယ်။
5. Group ရွေးပြီး Welcome Message / Rules ကိုပြင်ပြီး Save နှိပ်ပါ။

## လုံခြုံရေး
- `.env` ကို GitHub/public chat ထဲ မတင်ပါနှင့်။
- Bot Token ကို browser JavaScript ထဲ မထည့်ပါနှင့်။
- Telegram `initData` ကို server-side validate လုပ်ထားသည်။ `initDataUnsafe` ကို authentication အဖြစ် မယုံကြည်ပါနှင့်။
- Settings save တိုင်း Telegram group admin ဖြစ်ကြောင်း server က ပြန်စစ်သည်။
- HTTPS သာအသုံးပြုပါ။
