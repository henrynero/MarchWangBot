import os, json, time, hmac, hashlib, sqlite3, urllib.parse
from contextlib import contextmanager
from typing import Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "")
APP_BASE_URL = os.getenv("APP_BASE_URL", "")
DB_PATH = os.getenv("DATABASE_PATH", "./marchwangbot.db")
INIT_MAX_AGE = int(os.getenv("INIT_DATA_MAX_AGE_SECONDS", "3600"))

app = FastAPI(title="MarchWangBot Mini App API")
app.mount("/static", StaticFiles(directory="static"), name="static")

@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS groups (
            chat_id INTEGER PRIMARY KEY, title TEXT NOT NULL, chat_type TEXT NOT NULL,
            added_at INTEGER NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS settings (
            chat_id INTEGER PRIMARY KEY, welcome TEXT NOT NULL DEFAULT 'Welcome {name} to {group}! 👑',
            rules TEXT NOT NULL DEFAULT '1. Respect all members.\\n2. No spam.\\n3. Follow admin instructions.',
            updated_at INTEGER NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, event TEXT NOT NULL,
            actor_id INTEGER, created_at INTEGER NOT NULL)""")
init_db()

def validate_init_data(raw: str) -> dict:
    if not BOT_TOKEN:
        raise HTTPException(503, "Server is missing BOT_TOKEN.")
    try:
        parsed = urllib.parse.parse_qsl(raw, keep_blank_values=True, strict_parsing=True)
        data = dict(parsed)
        received_hash = data.pop("hash", None)
        data.pop("signature", None)
        if not received_hash:
            raise ValueError("Missing hash")
        check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        expected = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, received_hash):
            raise ValueError("Bad signature")
        auth_date = int(data.get("auth_date", "0"))
        now = int(time.time())
        if auth_date > now + 30 or now - auth_date > INIT_MAX_AGE:
            raise ValueError("Expired initData")
        user = json.loads(data["user"])
        if not isinstance(user.get("id"), int):
            raise ValueError("Missing user id")
        return user
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(401, "Telegram login is invalid or expired. Reopen the Mini App from Telegram.")

async def get_user(request: Request) -> dict:
    raw = request.headers.get("X-Telegram-Init-Data", "")
    if not raw:
        raise HTTPException(401, "Open this app from Telegram to sign in.")
    return validate_init_data(raw)

async def telegram(method: str, payload: dict):
    if not BOT_TOKEN:
        raise HTTPException(503, "Bot token is not configured on the server.")
    async with httpx.AsyncClient(timeout=12) as client:
        try:
            r = await client.post(f"https://api.telegram.org/bot{BOT_TOKEN}/{method}", json=payload)
            data = r.json()
        except Exception:
            raise HTTPException(502, "Telegram API is temporarily unavailable.")
    if not data.get("ok"):
        raise HTTPException(502, f"Telegram API error for {method}. Check bot permissions and group ID.")
    return data["result"]

async def ensure_group_admin(chat_id: int, user_id: int):
    # First check that the bot can see the group and is an administrator.
    bot_info = await telegram("getMe", {})
    bot_member = await telegram("getChatMember", {"chat_id": chat_id, "user_id": bot_info["id"]})
    if bot_member.get("status") not in ("administrator", "creator"):
        raise HTTPException(403, "MarchWangBot must be an administrator in this group.")
    member = await telegram("getChatMember", {"chat_id": chat_id, "user_id": user_id})
    if member.get("status") not in ("administrator", "creator"):
        raise HTTPException(403, "Only group admins can change these settings.")

def ensure_group_known(chat_id: int):
    with db() as c:
        row = c.execute("SELECT chat_id FROM groups WHERE chat_id=?", (chat_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Group not found yet. Add the bot to the group and wait for its update.")

class SettingsIn(BaseModel):
    welcome: str = Field(min_length=1, max_length=1500)
    rules: str = Field(min_length=1, max_length=4000)

@app.get("/", response_class=HTMLResponse)
async def index():
    return FileResponse("static/index.html")

@app.get("/health")
async def health():
    return {"ok": True, "app": "MarchWangBot Mini App"}

@app.get("/api/me")
async def me(request: Request):
    user = await get_user(request)
    return {"id": user["id"], "first_name": user.get("first_name", ""),
            "username": user.get("username", ""), "premium": bool(user.get("is_premium", False))}

@app.get("/api/groups")
async def groups(request: Request):
    await get_user(request)
    with db() as c:
        rows = c.execute("SELECT chat_id,title,chat_type,added_at FROM groups ORDER BY title").fetchall()
    return {"groups": [dict(r) for r in rows]}

@app.get("/api/groups/{chat_id}/settings")
async def get_settings(chat_id: int, request: Request):
    user = await get_user(request)
    ensure_group_known(chat_id)
    await ensure_group_admin(chat_id, user["id"])
    with db() as c:
        row = c.execute("SELECT welcome,rules,updated_at FROM settings WHERE chat_id=?", (chat_id,)).fetchone()
        group = c.execute("SELECT title FROM groups WHERE chat_id=?", (chat_id,)).fetchone()
        if not row:
            c.execute("INSERT INTO settings(chat_id, updated_at) VALUES(?,?)", (chat_id, int(time.time())))
            row = c.execute("SELECT welcome,rules,updated_at FROM settings WHERE chat_id=?", (chat_id,)).fetchone()
    return {"chat_id": chat_id, "title": group["title"], **dict(row)}

@app.put("/api/groups/{chat_id}/settings")
async def save_settings(chat_id: int, body: SettingsIn, request: Request):
    user = await get_user(request)
    ensure_group_known(chat_id)
    await ensure_group_admin(chat_id, user["id"])
    with db() as c:
        c.execute("""INSERT INTO settings(chat_id,welcome,rules,updated_at) VALUES(?,?,?,?)
            ON CONFLICT(chat_id) DO UPDATE SET welcome=excluded.welcome,
            rules=excluded.rules,updated_at=excluded.updated_at""",
            (chat_id, body.welcome.strip(), body.rules.strip(), int(time.time())))
        c.execute("INSERT INTO events(chat_id,event,actor_id,created_at) VALUES(?,?,?,?)",
                  (chat_id, "settings_updated", user["id"], int(time.time())))
    return {"ok": True, "message": "Settings saved."}

@app.get("/api/groups/{chat_id}/logs")
async def logs(chat_id: int, request: Request):
    user = await get_user(request)
    ensure_group_known(chat_id)
    await ensure_group_admin(chat_id, user["id"])
    with db() as c:
        rows = c.execute("SELECT event,actor_id,created_at FROM events WHERE chat_id=? ORDER BY id DESC LIMIT 50",
                         (chat_id,)).fetchall()
    return {"logs": [dict(r) for r in rows]}

@app.post("/telegram/webhook")
async def webhook(request: Request, x_telegram_bot_api_secret_token: Optional[str] = Header(default=None)):
    if not WEBHOOK_SECRET or not hmac.compare_digest(x_telegram_bot_api_secret_token or "", WEBHOOK_SECRET):
        raise HTTPException(403, "Invalid webhook secret.")
    update = await request.json()
    if "my_chat_member" in update:
        item = update["my_chat_member"]
        chat, member = item.get("chat", {}), item.get("new_chat_member", {})
        if chat.get("type") in ("group", "supergroup") and member.get("status") not in ("left", "kicked"):
            with db() as c:
                c.execute("INSERT INTO groups(chat_id,title,chat_type,added_at) VALUES(?,?,?,?) "
                          "ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title,chat_type=excluded.chat_type",
                          (chat["id"], chat.get("title", "Telegram Group"), chat["type"], int(time.time())))
                c.execute("INSERT OR IGNORE INTO settings(chat_id,updated_at) VALUES(?,?)", (chat["id"], int(time.time())))
        elif chat.get("type") in ("group", "supergroup") and member.get("status") in ("left", "kicked"):
            with db() as c:
                c.execute("DELETE FROM groups WHERE chat_id=?", (chat["id"],))
        return {"ok": True}
    msg = update.get("message", {})
    chat = msg.get("chat", {})
    text = (msg.get("text") or "").strip()
    if chat.get("type") in ("group", "supergroup"):
        with db() as c:
            c.execute("INSERT INTO groups(chat_id,title,chat_type,added_at) VALUES(?,?,?,?) "
                      "ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title",
                      (chat["id"], chat.get("title", "Telegram Group"), chat["type"], int(time.time())))
            c.execute("INSERT OR IGNORE INTO settings(chat_id,updated_at) VALUES(?,?)", (chat["id"], int(time.time())))
    if text.startswith("/start") or text.startswith("/help"):
        await telegram("sendMessage", {"chat_id": chat["id"], "text":
            "👑 MarchWangBot — Premium Group Control\\n\\n"
            "/id — Show chat ID\\n/rules — Show group rules\\n"
            "Open the Control Panel menu to manage welcome text and rules."})
    elif text.startswith("/id"):
        await telegram("sendMessage", {"chat_id": chat["id"], "text": f"Chat ID: {chat['id']}"})
    elif text.startswith("/rules"):
        with db() as c:
            row = c.execute("SELECT rules FROM settings WHERE chat_id=?", (chat["id"],)).fetchone()
        await telegram("sendMessage", {"chat_id": chat["id"], "text": row["rules"] if row else "Rules are not set yet."})
    for member in msg.get("new_chat_members", []):
        with db() as c:
            row = c.execute("SELECT welcome FROM settings WHERE chat_id=?", (chat["id"],)).fetchone()
        template = row["welcome"] if row else "Welcome {name} to {group}! 👑"
        welcome = template.replace("{name}", member.get("first_name", "member")).replace("{group}", chat.get("title", "the group"))
        await telegram("sendMessage", {"chat_id": chat["id"], "text": welcome})
    return {"ok": True}
