const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor("#080909"); tg.setBackgroundColor("#080909"); } catch(e) {} }
const $ = (id) => document.getElementById(id);
const initData = tg?.initData || "";
let selectedChat = "";
function setNotice(msg, error=false){ $("notice").textContent=msg; $("notice").style.borderColor=error?"#a43d3d":"#5c4525"; }
async function api(path, options={}) {
  const headers = {"Content-Type":"application/json","X-Telegram-Init-Data":initData,...(options.headers||{})};
  const res = await fetch(path,{...options,headers});
  const data = await res.json().catch(()=>({detail:"Unexpected server response"}));
  if(!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}
async function loadSettings() {
  selectedChat=$("groups").value;
  $("saveStatus").textContent="";
  if(!selectedChat){ $("welcome").value=""; $("rules").value=""; $("groupHint").textContent="အရင်ဆုံး group တစ်ခုရွေးပါ။"; return; }
  try {
    const s=await api(`/api/groups/${encodeURIComponent(selectedChat)}/settings`);
    $("welcome").value=s.welcome; $("rules").value=s.rules;
    $("groupHint").textContent=`${s.title} • Admin permission verified`;
  } catch(e){ $("groupHint").textContent=e.message; $("saveStatus").textContent=""; }
}
async function boot(){
  if(!initData){ $("access").textContent="TELEGRAM ONLY"; $("groupCount").textContent="—"; setNotice("ဒီ Preview ကို browser မှာ တိုက်ရိုက်ဖွင့်ထားပါတယ်။ အမှန်တကယ် login ဝင်ရန် HTTPS URL ကို Telegram Mini App အဖြစ်ဖွင့်ပါ။",true); $("groups").innerHTML='<option value="">Telegram login လိုအပ်သည်</option>'; return; }
  try{
    const me=await api("/api/me");
    $("hello").textContent=`Welcome, ${me.first_name || "Commander"}. Your control center is ready.`;
    $("access").textContent="VERIFIED";
    const result=await api("/api/groups");
    $("groupCount").textContent=result.groups.length;
    $("groups").innerHTML='<option value="">— Select a group —</option>'+result.groups.map(g=>`<option value="${g.chat_id}">${escapeHtml(g.title)} (${g.chat_type})</option>`).join("");
    if(result.groups.length===0){setNotice("Group မတွေ့သေးပါ။ Bot ကို group ထဲထည့်ပြီး Admin ပေးပါ၊ ထို့နောက် group ထဲမှာ /start ပို့ပါ။",true);}
    else setNotice("Telegram identity verified. Settings ပြင်ရန် group ကိုရွေးပါ။");
  }catch(e){$("access").textContent="ERROR";setNotice(e.message,true);}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("groups").addEventListener("change",loadSettings);
$("save").addEventListener("click",async()=>{
  if(!selectedChat){$("saveStatus").textContent="Group တစ်ခုရွေးပါ။";return;}
  $("save").disabled=true;$("saveStatus").textContent="Saving securely…";
  try{
    await api(`/api/groups/${encodeURIComponent(selectedChat)}/settings`,{method:"PUT",body:JSON.stringify({welcome:$("welcome").value,rules:$("rules").value})});
    $("saveStatus").textContent="✓ Settings saved successfully.";
    if(tg?.HapticFeedback) tg.HapticFeedback.notificationOccurred("success");
  }catch(e){$("saveStatus").textContent=`မသိမ်းနိုင်ပါ: ${e.message}`;}
  finally{$("save").disabled=false;}
});
boot();
